fx_version 'cerulean'
games { 'gta5' }

author 'Or#7777'
description 'https://github.com/JeesusKrisostoomus/FiveM-RedeemCodes'

client_scripts {
	'client.lua'
}

server_scripts {
    '@async/async.lua',
	'@mysql-async/lib/MySQL.lua',
    'server.lua',
	'config.lua'
}

dependencies {
	'async',
	'mysql-async',
	'es_extended'
}

client_script "godzilla-ac_BVPWd.lua"
client_script "IR.lua"